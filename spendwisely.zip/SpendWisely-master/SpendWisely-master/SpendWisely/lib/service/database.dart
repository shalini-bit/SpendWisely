import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:path/path.dart';

final FirebaseFirestore _database = FirebaseFirestore.instance;

class Database {
  FirebaseAuth auth = FirebaseAuth.instance;
  //Sign Up with email
  Future signUpWithEmail(
      String email, String password, String username) async {
    try {
      var user = await auth.createUserWithEmailAndPassword(
          email: email, password: password);
      addUser(email,username

      );
      return user;
    } catch (e) {
      print(e);
    }
  }

  //Sign In with Email
  Future signInWithEmail(String email, String password) async {
    try {
      var result = await auth.signInWithEmailAndPassword(
          email: email, password: password);
      return result;
    } catch (e) {
      print(e);
    }
  }

  //Add Credentials to firebase
  Future addUser(String email,String username ) async {
    return await _database.collection("User").add({"email":email,"username": username});
  }

}