import 'package:flutter/material.dart';

const Color black = Color(0xFF000000);
const Color white = Color(0xFFFFFFFF);
const Color green = Color(0xff00e676);
const Color red = Color(0xffb71c1c);
const Color blue = Color(0xff2962ff);

Color primaryColor = Color(0xff0f284b);
Color secondaryColor = Color(0xff232c51);
Color logoPurple = Color(0xff01579b);
Color Tealss = Color(0xffeceff1);
